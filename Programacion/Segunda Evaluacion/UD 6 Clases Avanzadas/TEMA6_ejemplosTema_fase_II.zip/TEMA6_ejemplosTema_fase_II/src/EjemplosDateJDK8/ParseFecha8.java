package EjemplosDateJDK8;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class ParseFecha8 {

    public static void main(String[] args) {
        // *************************************************
        // RECOGIDA DE FECHAS POR TECLADO
        //*****************************************************
        Scanner sc = new Scanner(System.in);

        System.out.println("Introduce fecha con formato 02.feb.2017: ");
        String fechateclado = sc.nextLine();

        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd.MMM.yyyy");

        LocalDate f;

        f = LocalDate.parse(fechateclado, formato);
        System.out.println("FECHA ESCRITA: " + f);

    }

}

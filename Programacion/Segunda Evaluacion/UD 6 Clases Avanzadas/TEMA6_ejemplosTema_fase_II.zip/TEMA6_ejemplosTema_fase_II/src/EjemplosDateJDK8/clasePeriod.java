package EjemplosDateJDK8;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.temporal.ChronoUnit;

public class clasePeriod {
    public static void main(String[] args) {
        LocalDate hoy = LocalDate.now();
        LocalDate finCurso = LocalDate.of(2017, Month.JUNE, 16);

        Period quedan = Period.between(hoy, finCurso);
        System.out.println("Quedan: " + quedan);
        int meses = quedan.getMonths();
        System.out.println("Faltan " + meses + " meses para fin de curso");
     
    }
}

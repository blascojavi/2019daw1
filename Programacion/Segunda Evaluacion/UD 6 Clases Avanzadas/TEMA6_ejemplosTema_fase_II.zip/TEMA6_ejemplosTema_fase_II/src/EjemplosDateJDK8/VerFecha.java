
package EjemplosDateJDK8;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;


public class VerFecha {

    public static void main(String[] args) {
        
        //Hoy es martes, dia 17 de enero del año 2017
        System.out.println(DateTimeFormatter.ofPattern("'Hoy es ' EEEE, 'dia ' d 'de '  MMMM 'del año ' yyyy").format(LocalDate.now()));
         
        
        DateTimeFormatter formateador = DateTimeFormatter.ofPattern("HH:mm a");
        String fecha = LocalTime.now().format(formateador);
        System.out.println("y son las " + fecha);
    }
    
}

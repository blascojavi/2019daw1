package EjemplosDateJDK8;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class Idiomas {
 
    public static void main(String[] args) {
         LocalDate hoy = LocalDate.now();   

        DateTimeFormatter patron = DateTimeFormatter.ofPattern("yyyy.MMMM.dd");
        DateTimeFormatter patronEspañol = DateTimeFormatter.ofPattern("yyyy.MMMM.dd", new Locale("es", "ES"));
        DateTimeFormatter patronFrances = DateTimeFormatter.ofPattern("yyyy.MMMM.dd", new Locale("FR"));
        DateTimeFormatter patronAleman = DateTimeFormatter.ofPattern("yyyy.MMMM.dd", Locale.ITALY);

        System.out.println("segun maquina. " + hoy.format(patron));
        System.out.println("español. " + hoy.format(patronEspañol));
        System.out.println("frances. " + hoy.format(patronFrances));
        System.out.println("italiano. " + hoy.format(patronAleman));
    }
    
}

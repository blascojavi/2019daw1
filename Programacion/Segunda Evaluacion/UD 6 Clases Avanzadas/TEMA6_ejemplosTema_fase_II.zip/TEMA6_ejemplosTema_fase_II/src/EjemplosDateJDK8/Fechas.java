package EjemplosDateJDK8;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.ZonedDateTime;

public class Fechas {

    public static void main(String[] args) {
        LocalDate hoy = LocalDate.now();
        System.out.println(hoy);

//Ejemplo: la hora actual (formato ISO 8601 hh:mm:ssZ)
        LocalTime ahora = LocalTime.now();
        System.out.println(ahora);

//Ejemplo: la fecha y hora actuales
        LocalDateTime instante = LocalDateTime.now();
        System.out.println(instante);
        
//Ejemplo: crear una fecha 02-01-2016 
        LocalDate fechaTope = LocalDate.of(2016, 01, 02);
        System.out.println(fechaTope);
        LocalDateTime fecha = LocalDateTime.of(fechaTope, ahora); 
        System.out.println(fecha);

        ZonedDateTime f = ZonedDateTime.now();
        System.out.println("f : " + f);
        
        DayOfWeek lunes = DayOfWeek.MONDAY;
        System.out.println("8 días despues será: " + lunes.plus(8));
        System.out.println("2 días antes fue: " + lunes.minus(2));

        Month enero = Month.JANUARY;
        LocalDate fecha2 = LocalDate.of(2016, Month.JULY, 02);

//Sumar o restar meses.
        System.out.println("2 meses despues será: " + enero.plus(2));
        System.out.println("1 mes antes fue: " + enero.minus(1));

//        boolean isAfter(LocalDate fecha) : saber si es posterior a la fecha pasada por  parámetro
        if (hoy.isAfter(fechaTope)) {
            System.out.println("Has llegado tarde");
        }

//LocalDate  plusMonths(int  x)  : devuelve la fecha con X meses más
        LocalDate devolucion = hoy.plusMonths(2);

//LocalDate  plusMonths(int  x)  : devuelve la fecha con  X meses más
//LocalDate  plusDays(int  x)  : devuelve la fecha con  X dias más
        LocalDate devolucion2 = hoy.plusDays(10);
        LocalDate devolucion3 = hoy.plusMonths(1).plusDays(12);

//DayOfWeek   getDayOfWeek(): dia de la semana de una fecha
        System.out.println("Hoy es: " + hoy.getDayOfWeek());

    }

}


package EjemplosDateJDK8;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Month;
import java.time.temporal.ChronoUnit;


public class claseDuration {

   
    public static void main(String[] args) {
        Instant   hoy= Instant.now();
      Instant   finCurso= Instant.parse("2017-06-16T00:00:00.00Z"); 

     System.out.println("Faltan "  + Duration.between(hoy , finCurso).toDays() + " dias para fin de curso");
     
     LocalTime ahora = LocalTime.now();
     Duration horas = Duration.ofHours(2);
//     LocalTime finPeli = ahora.plus(2, ChronoUnit.HOURS);
     LocalTime finPeli = ahora.minus(horas);
     
        System.out.println(finPeli);
        System.out.println(Duration.between( ahora, finPeli).toHours());

    }
    
}

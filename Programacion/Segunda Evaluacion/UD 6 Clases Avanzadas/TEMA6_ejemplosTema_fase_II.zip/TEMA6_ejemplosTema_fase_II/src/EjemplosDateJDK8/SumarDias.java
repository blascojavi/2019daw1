package EjemplosDateJDK8;

import java.util.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class SumarDias {

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("¿Cuantos dias tardaras en terminar la revisión?");
        long nDias = Long.parseLong(sc.nextLine());

      
        LocalDate hoy = LocalDate.now();

        LocalDate fechaRevision = hoy.plusDays(nDias);

        DateTimeFormatter formateador = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
        System.out.println("La revision se entregará el dia:" + formateador.format(fechaRevision));

    }
}

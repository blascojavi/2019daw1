
package enumerados;

enum DiaLaborable{
    Lunes,
    Martes,
    Miercoles,
    Jueves,
    Viernes
}
public class Clase1 {
    int atributo;
    DiaLaborable dia;    
}


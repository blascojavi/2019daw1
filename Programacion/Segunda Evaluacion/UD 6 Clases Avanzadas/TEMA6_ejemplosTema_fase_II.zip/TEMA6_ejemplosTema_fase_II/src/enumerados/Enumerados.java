
package enumerados;


public class Enumerados {

    int identificador;

    enum EstadoTanque {
        //El tanque está lleno de Agua
        LLENO,
        //El tanque está vacío de Agua
        VACIO,
        //El tanque está a la mitad de su capacidad
        MEDIO
    }

}

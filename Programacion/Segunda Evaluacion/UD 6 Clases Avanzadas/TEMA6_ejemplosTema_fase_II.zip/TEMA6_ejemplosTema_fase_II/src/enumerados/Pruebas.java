package enumerados;

//import enumerados.Enumerados.EstadoTanque;
public class Pruebas {

    public static void main(String[] args) {
        ColorSemaforo color = ColorSemaforo.VERDE;

        if (color == ColorSemaforo.VERDE) {
            System.out.println("PASE semaforo verde");
        } else {
            System.out.println("VES FRENANDO semaforo rojo o ambar");
        }

        ColorSemaforo[] valores = ColorSemaforo.values();

        for (ColorSemaforo c : valores) {
            System.out.println(c);
        }

        Enumerados.EstadoTanque e2 = Enumerados.EstadoTanque.VACIO;

        //Para poder usar EstadoTanque directamente se necesita:
        // import enumerados.Enumerados.EstadoTanque;
//         EstadoTanque e1 = EstadoTanque.VACIO;
        DiaLaborable dias = DiaLaborable.Martes;

    }

}

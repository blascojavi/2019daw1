
package enumerados;


public enum ColorSemaforo {
    ROJO,
    VERDE,
    AMBAR
}

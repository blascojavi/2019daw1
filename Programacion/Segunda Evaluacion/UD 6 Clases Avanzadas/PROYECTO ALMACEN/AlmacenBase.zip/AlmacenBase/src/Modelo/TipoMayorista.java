
package Modelo;


public enum TipoMayorista {
    GRAN_SUPERFICIE,TIENDA;
}

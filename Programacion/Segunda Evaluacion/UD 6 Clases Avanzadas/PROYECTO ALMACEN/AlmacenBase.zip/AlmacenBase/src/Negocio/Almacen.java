
package Negocio;


public class Almacen {


    public static void main(String[] args) {
        
        
       MenuPrincipal m= new MenuPrincipal();    
       m.inciarAplicacion();
      
       
        
    }
    
}

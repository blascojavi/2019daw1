
package ModifStatic;


public class Matematicas {

    public static double sumar(double a, double b) {
        return a + b;
    }

    public static double restar(double a, double b) {
        return a - b;
    }

    static public int mult(int a, int b) {
        return a * b;
    }
}

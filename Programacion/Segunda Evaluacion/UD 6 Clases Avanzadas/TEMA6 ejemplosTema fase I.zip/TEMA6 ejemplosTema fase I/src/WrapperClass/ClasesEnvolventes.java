package WrapperClass;

public class ClasesEnvolventes {

    public static void main(String[] args) {
        String cadena = "54321";
        Integer num1 = Integer.valueOf(cadena);
        int num2 = Integer.parseInt(cadena);
        double num3 = Double.parseDouble(cadena);

        String cadena2 = "123.55";
        Double num4 = Double.valueOf(cadena);
        double num5 = Double.parseDouble(cadena);

        Integer n = 12;
        String texto = n.toString();
        int entero = n.shortValue();
        double decimal = n.doubleValue();

        /* **********************************
              CLASE Character
 ************************************ */
        boolean digito = Character.isDigit('2');
        boolean digito2 = Character.isDigit('a');

        boolean letra = Character.isLetter('b');
        boolean letra2 = Character.isLetter('2');
        System.out.println(Character.toUpperCase('a'));

    }

}

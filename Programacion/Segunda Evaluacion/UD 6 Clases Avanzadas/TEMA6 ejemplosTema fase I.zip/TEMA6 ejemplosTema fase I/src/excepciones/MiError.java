
package excepciones;

public class MiError extends RuntimeException {

    public MiError() {
        super("Error generado");
    }

    public MiError(String mensaje) {
        super("color " + mensaje + " no permitido");
    }
}

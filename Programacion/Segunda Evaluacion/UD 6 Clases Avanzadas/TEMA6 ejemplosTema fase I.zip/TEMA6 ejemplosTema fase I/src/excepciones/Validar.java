
package excepciones;

public class Validar {

    public static boolean esValido(String color) {
        boolean retorno=false;
        
        if (color.equals("rojo") || color.equals("verde")) {
            throw new MiError(color);
        } else 
            retorno=true;
        
        return retorno;
    }
}

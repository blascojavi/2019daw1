
package excepciones;

import java.util.Scanner;


public class Test {

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        String colorCoche;
        
        System.out.println("Dime un color para el coche");
        colorCoche=sc.next();
        
        System.out.println(comprobarColor(colorCoche));
        
       
        
    }
    
    public static String comprobarColor(String color){
        String correcto="";
         try {
             if (Validar.esValido(color) == true)
                 correcto = "valido";
        } catch (MiError e) {
            correcto = e.getMessage();
        }
         
         return correcto;
    }
}

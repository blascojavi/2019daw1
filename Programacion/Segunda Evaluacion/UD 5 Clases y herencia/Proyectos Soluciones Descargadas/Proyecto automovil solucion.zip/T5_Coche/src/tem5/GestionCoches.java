package tem5;

import java.util.*;

public class GestionCoches {

    public static void main(String[] args) {

        
        Scanner tec = new Scanner(System.in);
        String matricula, modelo;
        Coche co;

        System.out.println("Introduce la matricula deseada:");
        matricula = tec.nextLine();
        System.out.println("Introduce el modelo deseado");
        modelo = tec.nextLine();

        co = new Coche(matricula, modelo);
        co.setColor("rojo");
        
        if (co.setTipo("ddddddde") == true) {
            System.out.println("tipo: " + co.getTipo());
        }else{
            System.out.println("Tipo incorrecto");
        }

        System.out.println(co.VerDatosBasicos());

        System.out.println(co.toString());

        
        List<Coche> lista = new ArrayList<>();
        
        lista.add(new Coche("2222-JKL" , "seat cordoba"));
        lista.add(co);
        
        System.out.println(lista);
    
    }
}

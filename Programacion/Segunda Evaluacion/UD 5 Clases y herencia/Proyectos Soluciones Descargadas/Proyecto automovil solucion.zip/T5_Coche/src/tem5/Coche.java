package tem5;

public class Coche {

    private String modelo;
    private String color;
    private boolean metalizada;
    private String matricula;
    private String tipo;
    private int añofab;
    private String seguro;

    public Coche(String matricula, String modelo) {
        this.matricula = matricula;
        this.modelo = modelo;
        añofab = 2009;
    }

    public String getModelo() {
        return modelo;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public boolean getMetalizada() {
        return metalizada;
    }

    public void setMetalizada(boolean metalizada) {
        this.metalizada = metalizada;
    }

    public String getMatricula() {
        return matricula;
    }

    public boolean setTipo(String tipo) {
        boolean actualizado = false;
        if (tipo.equals("mini") || tipo.equals("familiar")
                || tipo.equals("utilitario") || tipo.equals("deportivo")) {
            this.tipo = tipo;
            actualizado = true;
        }
        return actualizado;
    }

    public String getTipo() {
        return tipo;
    }

    public int getAñofab() {
        return añofab;
    }

    public void setAñofab(int añofab) {
        this.añofab = añofab;
    }

    public String getSeguro() {
        return seguro;
    }

    public boolean setSeguro(String seguro) {
        boolean actualizado = false;
        if (seguro.equals("a terceros") || seguro.equals("todo riesgo")) {
            this.seguro = seguro;
            actualizado = true;
        }
        return actualizado;
    }

    public String VerDatosBasicos() {
        String verdatos;
        verdatos = "El coche de matrícula " + matricula;
        if (modelo != null) {
            verdatos += " (modelo " + modelo + ")";;
        }
        if (color != null) {
            verdatos += " de color " + color;;
        }
        return verdatos;
    }

    @Override  //REDEFINE EL MÉTODO
    public String toString() {
        return this.matricula + "  -  " + this.modelo;
    }
}

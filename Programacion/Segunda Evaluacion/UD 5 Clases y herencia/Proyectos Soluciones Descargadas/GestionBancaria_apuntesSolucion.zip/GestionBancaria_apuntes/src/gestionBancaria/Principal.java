package gestionBancaria;

public class Principal {

    public static void main(String[] args) {
        Persona titular = new Persona("33444666S", "Juan Sanchez");
        CuentaBancaria c1 = new CuentaBancaria(12235443, titular);

        Persona p1 = new Persona("19222333Y", "Ana Sanchez");
        Persona p2 = new Persona("22888444D", "Laura Sanchez");
        Persona p3 = new Persona("22888444D", "laura sanchez");

        if (c1.autorizar(p1)) {
            System.out.println(p1.getNombre() + " ha sido autorizada");
        }
        if (c1.autorizar(p2)) {
            System.out.println(p2.getNombre() + " ha sido autorizada");
        }
        if (c1.autorizar(p3)) {
            System.out.println(p3.getNombre() + " ha sido autorizada");
        }

        if (p2.igual(p3)) {
            System.out.println("Tienen el mismo nif");
        }

    }

}

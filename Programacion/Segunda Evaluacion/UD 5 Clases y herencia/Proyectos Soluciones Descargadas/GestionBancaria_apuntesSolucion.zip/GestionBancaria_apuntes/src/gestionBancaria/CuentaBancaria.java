package gestionBancaria;

import java.util.HashSet;
import java.util.Set;

public class CuentaBancaria {

    private long numCuenta;
    private Persona titular;
    private Set<Persona> autorizados = new HashSet<>();

    public CuentaBancaria(long ncuenta, Persona titular) {
        this.numCuenta = ncuenta;
        this.titular = titular;
    }

    //NO HAY METODOS SET PORQUE NO SE DEBE PERMITIR MODIFICAR DATOS DESPUES DE 
    // CREAR EL OBJETO
    public long getNumCuenta() {
        return numCuenta;
    }

    public Persona getTitular() {
        return titular;
    }

    public boolean autorizar(Persona autorizado) {
        return autorizados.add(autorizado);
    }

}

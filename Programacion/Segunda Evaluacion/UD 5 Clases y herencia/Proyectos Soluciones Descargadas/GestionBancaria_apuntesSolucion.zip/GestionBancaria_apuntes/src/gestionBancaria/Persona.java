
package gestionBancaria;


public class Persona {

    private String nif;
    private String nombre;

      
    public Persona(String nif, String nombre) {
        this.nif = nif;
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public String getNif() {
        return nif;
    }
    
    //COMPARA ESTA PERSONA EN LA QUE ESTAMOS CON OTRO OBJETO PERSON (PARÁMETRO)
    public boolean igual(Persona person){
        boolean resultado=false;
        
        if(nif.equalsIgnoreCase(person.getNif())){
            resultado=true;
        }
        return resultado;
    }
    
     //COMPARA NIF DE ESTA PERSONA EN LA QUE ESTAMOS CON OTRO NIF
     public boolean igual(String nif){
        boolean resultado=false;
        
        if(this.nif.equalsIgnoreCase(nif)){
            resultado=true;
        }
        return resultado;
        
        //OTRA FORMA DE ESCRIBIRLO
        // return this.nif.equalsIgnoreCase(dni);
    }
    
    
    @Override
    public String toString(){
        String resultado = nombre + "("+ nif + ")";
        return resultado;
    }
}

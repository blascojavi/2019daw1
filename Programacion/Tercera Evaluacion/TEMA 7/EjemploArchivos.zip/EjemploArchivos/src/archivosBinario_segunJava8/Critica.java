
package archivosBinario_segunJava8;


import java.io.Serializable;


public class Critica implements Serializable {
    private int id;
    private double valoracion;
    private String comentario;
    private static int numCriticas=0;
    
    
    public Critica(){
        numCriticas++;
        id=numCriticas;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getValoracion() {
        return valoracion;
    }

    public void setValoracion(double valoracion) {
        this.valoracion = valoracion;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public static int getNumCriticas() {
        return numCriticas;
    }

    public static void setNumCriticas(int numCriticas) {
        Critica.numCriticas = numCriticas;
    }

    @Override
    public String toString() {
        return  getId() + "\t"+ getValoracion() + "\t\t" + getComentario() + "\n";
    }
    
    
    
    
}

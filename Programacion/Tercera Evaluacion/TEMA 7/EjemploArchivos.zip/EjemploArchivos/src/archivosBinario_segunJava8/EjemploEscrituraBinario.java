package archivosBinario_segunJava8;

import java.io.File;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.Date;

public class EjemploEscrituraBinario {

    public static void main(String[] args) {

        Pelicula peli2 = new Pelicula();
        peli2.setNombre("El Padrino II");
        peli2.setDuracion(180);

        Critica c3 = new Critica();
        c3.setValoracion(8);
        c3.setComentario("Vale la pena");

        Critica c4 = new Critica();
        c4.setValoracion(5);
        c4.setComentario("Interesante pero larga");

        peli2.getCriticas().add(c3);
        peli2.getCriticas().add(c4);

        Path f = Paths.get("SalidaObjetos.dat");

        try (OutputStream fileOutput = Files.newOutputStream(f);
                ObjectOutputStream salida = new ObjectOutputStream(fileOutput)) {
            salida.writeObject(LocalDate.now());
            salida.writeObject(peli2);
           
          

        } catch (IOException ex) {
            System.out.println("Error al abrir el fichero" + ex.getMessage());
        }
    }
}

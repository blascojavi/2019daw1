
package archivosBinario_segunJava8;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


public class Pelicula implements Serializable {
    private int id;
    private String nombre;
    private int duracion;
    private List<Critica> criticas= new ArrayList();
    private static int numPeliculas=0;
    
    public Pelicula(){
        numPeliculas++;
        id= numPeliculas;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Critica> getCriticas() {
        return criticas;
    }

    public void setCriticas(List<Critica> criticas) {
        this.criticas = criticas;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }
    
    
    
    @Override
    public String toString(){
        String informacion = "ID: "+this.id+" NOMBRE: "+this.nombre + "\n";
        informacion += "CRITICAS: \n";
        informacion += "IDCRIT    VALORACION     COMENTARIO \n";
        for(Critica c :criticas){
            informacion += c.toString();
        }
        return informacion;
    }
    
    
}

package archivosBinario_segunJava8;

import java.io.InputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;

public class EjemploLecturaBinario {

    public static void main(String[] args) {
        Path f = Paths.get("SalidaObjetos.dat");

        try (InputStream fileInput = Files.newInputStream(f);
                ObjectInputStream archivo = new ObjectInputStream(fileInput)) {
            
            LocalDate fecha = (LocalDate) archivo.readObject();
            Pelicula pelicula = (Pelicula) archivo.readObject();

            System.out.println(pelicula.toString());
            System.out.println(fecha.toString());

        } catch (ClassNotFoundException ex) {
            System.out.println("La clase no existe");
        } catch (IOException ex) {
            System.out.println("Error al abrir el fichero");
        }
    }

}

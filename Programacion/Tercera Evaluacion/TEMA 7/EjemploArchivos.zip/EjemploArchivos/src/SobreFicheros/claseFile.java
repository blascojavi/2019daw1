
package SobreFicheros;

import java.io.File;

public class claseFile {

    public static void main(String[] args) {
        File fichero = new File("archivoFile.txt");
        System.out.println("existe: " + fichero.exists());
        System.out.println("esichero: " + fichero.isFile());
        System.out.println("size: " + fichero.length());
        System.out.println("rutaAbs: " + fichero.getAbsolutePath());

        File nuevo = new File("archivoFile_bis.txt");
        boolean renombrado = fichero.renameTo(nuevo);
        System.out.println("renombrado: " + renombrado);

        boolean borrado = fichero.delete();
        System.out.println("borrado.... " + borrado);

    }

}

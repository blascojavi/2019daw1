package SobreFicheros;

import java.io.IOException;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.stream.Stream;

public class RecorrerDirectorio {

    public static void main(String[] args) {
        Path directorio = Paths.get("c:\\RAQUEL");

        try (Stream<Path> ficheros = Files.list(directorio)) {
            Iterator<Path> it = ficheros.iterator();
            while (it.hasNext()) {
                Path f= it.next();
                System.out.print(f.getFileName());
                System.out.println("  "+ Files.size(f)+" bytes");
            }
        } catch (IOException ex) {
            System.out.println("Error en la lista de ficheros");
        }

    }

}

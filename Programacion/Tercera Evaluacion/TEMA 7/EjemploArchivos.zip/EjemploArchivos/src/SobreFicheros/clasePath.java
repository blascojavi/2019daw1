package SobreFicheros;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.Level;
import java.util.logging.Logger;

public class clasePath {

    public static void main(String[] args) {
        Path fichero = Paths.get("archivoPath.txt");

        System.out.println("existe: " + Files.exists(fichero));
        System.out.println("es directorio?: " + Files.isDirectory(fichero));
        System.out.println("ruta absoluta: " + fichero.toAbsolutePath());
        try {
            System.out.println("size: " + Files.size(fichero) + "bytes");
        } catch (IOException ex) {
            System.out.println("Error al calcular tamaño del archivo");
        }

        File nuevo = new File("archivoPath_bis.txt");
        boolean renombrado = fichero.toFile().renameTo(nuevo);
        System.out.println("renombrado: " + renombrado);

        boolean borrado = fichero.toFile().delete();
        System.out.println("borrado.... " + borrado);

    }

}

package SobreFicheros;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;


public class claseFiles {

    public static void main(String[] args) {
        try {
            Path archivo = Paths.get("archivo.txt");

            Boolean existe = Files.exists(archivo);
            System.out.println("Existe..." + existe);

            boolean esFichero = Files.isWritable(archivo);
            System.out.println("Es un fichero.." + esFichero);

            long size = Files.size(archivo);
            System.out.println("Tamaño..." + size + "bytes");

            Path nuevo = Paths.get("archivo_bis.txt");
            Path copia = Files.copy(archivo, nuevo);

            if (existe) {
                Files.delete(archivo);
                System.out.println("BORRADO");
            }

        } catch (IOException ex) {
            System.out.println("Error en sistema de archivos");
        }

    }

}

package archivosTexto_segunJava8;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class EjemploEscrituraBufferedWriter {

    public static void main(String[] args) {

        Path archivo = Paths.get("Datos.txt");

        // USANDO EL SEGUNDO PARAMETRO, LE DECIMOS QUE USE OTRO CONJUNTO DE CARACTERES 
        //  Files.newBufferedWriter(archivo, StandardCharsets.UTF_8, StandardOpenOption.CREATE)
        // Si no decimos nada usa el UTF_8
        try (BufferedWriter out = Files.newBufferedWriter(archivo, StandardOpenOption.CREATE)) {
            out.write("linea 1 España\n\n");
            out.newLine();
            out.write("linea 2:  jamón");
            out.newLine();
            out.write("queso 3€");
            out.newLine();
        } catch (IOException e) {
            System.out.println("Error al abrir el fichero");
        }
    }
}

package pizzeria;


import java.net.URL;
import java.util.HashSet;
import java.util.ResourceBundle;
import java.util.Set;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory.ListSpinnerValueFactory;
import javafx.scene.control.TextArea;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Rectangle;
import modelo.Pizza;
import modelo.Precios;

public class PizzeriaController implements Initializable {

     private Pizza pizza;
     private Precios precios;
     
    @FXML
    private RadioButton radioNormal;
    @FXML
    private ToggleGroup grupoRadiosMasa;
    @FXML
    private RadioButton radioIntegral;
    @FXML
    private Label labelMasa;
    @FXML
    private Spinner<String> spinnerTamaño;
    @FXML
    private ComboBox<String> choiceTipo;
    @FXML
    private Label labelTipo;
    @FXML
    private Label labelIngredientes;
    @FXML
    private Label labelTamaño;
    @FXML
    private ListView<String> listViewIngredientes;
    @FXML
    private Label labelConsejoIngredientes;
    @FXML
    private Label labelPedido;
    @FXML
    private TextArea textareaPedido;
    @FXML
    private Rectangle rectanglePanelUsuario;   
    @FXML
    private Label precio;
    @FXML
    private Button bPrecio;

    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        crearPizzaValoresDefecto();

    }

    public void crearPizzaValoresDefecto() {

        pizza = new Pizza();
        precios = new Precios();
        pizza.setPrecios(precios);
        
        choiceTipo.setItems(FXCollections.observableArrayList(precios.tiposTiposPizza()));
        
        
        //CARGAMOS LOS COMPONENTES CON LOS VALORES OBTENIDOS DE LA CLAS PRECIO
        listViewIngredientes.setItems(FXCollections.observableArrayList(precios.tiposIngrediente()));
        listViewIngredientes.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE); //PERMITE SELECCIONAR VARIOS ELEMENTOS CON TECLA CTRL

        ListSpinnerValueFactory<String> factoryTamaños = new ListSpinnerValueFactory(FXCollections.observableArrayList(precios.tiposTamaño()));
        spinnerTamaño.setValueFactory(factoryTamaños);

        // valores por defecto 
        radioNormal.setSelected(true);
        choiceTipo.setValue("Barbacoa");


    }



    private void masa() {
        //SE OBTIENE EL VALOR SELECCIONADO EN EL RADIO BUTTON DE MASA
        String masa = ((RadioButton) grupoRadiosMasa.getSelectedToggle()).getText();
        //SE PASA LA MASA SELECCIONADA A LA PIZZA
        pizza.setMasa(masa);
    }



    public void tamaño() {
        String tamaño = spinnerTamaño.getValue();
        pizza.setTamaño(tamaño);
    }



    private void ingredientes() {
        Set<String> ingredientesExtra = new HashSet<>();

        //LOS INGREDIENTES SELECCIONADOS LOS ALMACENAMOS EN UN SET
        for (String ingrediente : listViewIngredientes.getSelectionModel().getSelectedItems()) {
            if (ingrediente != null) {
                ingredientesExtra.add(ingrediente);
            }
        }

        //ALMACENAMOS LOS INGREDIENTES EN LA PIZZA
        pizza.setIngredientesExtra(ingredientesExtra);
    }



    private void tipo() {
        String tipo = choiceTipo.getValue();
        pizza.setTipo(tipo);
    }



    @FXML
    private void calcularPrecioComposicion(ActionEvent event) {
         masa();
        tipo();
        tamaño();
        ingredientes();
        
         textareaPedido.setText(pizza.composicion());
        precio.setText(String.format("PRECIO TOTAL %.2f€", pizza.calcularPrecio()));
    }

  
}

package modelo;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Precios {

    private Map<String, Double> masa = new HashMap<>();
    private Map<String, Double> tipo = new HashMap<>();
    private Map<String, Double> ingredientes = new HashMap<>();
    private Map<String, Double> tamaño = new HashMap<>();

    public Precios() {
        masa.put("Normal", 1.);
        masa.put("Integral", 2.);

        ingredientes.put("Queso", 1.5);
        ingredientes.put("Tomate", 1.5);
        ingredientes.put("Cebolla", 1.5);
        ingredientes.put("jamón", 1.5);

        tipo.put("Barbacoa", 5.);
        tipo.put("Mexicana", 8.5);

        tamaño.put("mediana", 15.);
        tamaño.put("familiar", 30.);

    }

    public Precios(
            Map<String, Double> masa,
            Map<String, Double> tipo,
            Map<String, Double> ingredientes,
            Map<String, Double> tamaño
    ) {
        this.masa = masa;
        this.tipo = tipo;
        this.ingredientes = ingredientes;
        this.tamaño = tamaño;
    }

    public Double precioDeMasa(String masa) {
        return this.masa.get(masa);
    }

    public Double precioDeTipo(String tipo) {
        return this.tipo.get(tipo);
    }

    public Double precioDeIngredientes(Set<String> ingredientesAsumar) {
        Double precioIngredientes = 0.00;

        for (String ingrediente : ingredientesAsumar) {
            precioIngredientes += ingredientes.get(ingrediente);
        }

        return precioIngredientes;
    }

    public Double porcentajeDeTamaño(String tamaño) {
        return this.tamaño.get(tamaño);
    }

    public Set<String> tiposMasa() {
        return masa.keySet();
    }

    public Set<String> tiposTiposPizza() {
        return tipo.keySet();
    }

    public Set<String> tiposIngrediente() {
        return ingredientes.keySet();
    }

    public Set<String> tiposTamaño() {
        return tamaño.keySet();
    }
}

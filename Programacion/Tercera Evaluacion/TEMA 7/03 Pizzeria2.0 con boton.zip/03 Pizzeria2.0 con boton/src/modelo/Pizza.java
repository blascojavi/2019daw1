package modelo;


import java.util.Set;


public class Pizza {
    private int identificador;
    private String masa;
    private String tipo;
    private Set<String> ingredientesExtra;
    private String tamaño;

    private Precios precios;

    public Pizza() {
   
    }

    public Pizza(String masa, String tipo, Set<String> ingredientesExtra, String tamaño) {
        this.masa = masa;
        this.tipo = tipo;
        this.ingredientesExtra = ingredientesExtra;
        this.tamaño = tamaño;
    }

    public int getIdentificador() {
        return identificador;
    }

    public void setIdentificador(int identificador) {
        this.identificador = identificador;
    }

    public String getMasa() {
        return masa;
    }

    public void setMasa(String masa) {
        this.masa = masa;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Set<String> getIngredientesExtra() {
        return ingredientesExtra;
    }    
  
     
    public void setIngredientesExtra(Set<String> ingredientesExtra) {
        this.ingredientesExtra = ingredientesExtra;
    }

    public String getTamaño() {
        return tamaño;
    }

    public void setTamaño(String tamaño) {
        this.tamaño = tamaño;
    }

    public Precios getPrecios() {
        return precios;
    }

    public void setPrecios(Precios precios) {
        this.precios = precios;
    }

    public Double calcularPrecio() {
        Double precioTotal ;

        Double precioMasa = precios.precioDeMasa(this.masa);
        Double precioTipo = precios.precioDeTipo(this.tipo);
        Double porcentajeTamaño = precios.porcentajeDeTamaño(this.tamaño);
        Double precioIngredientes = precios.precioDeIngredientes(this.ingredientesExtra);

        
        precioTotal = (precioMasa + precioTipo + precioIngredientes);
        precioTotal += (precioTotal * (porcentajeTamaño / 100));

        return precioTotal;
    }

    public String composicion() {
        String cadena = "";
      

        Double precioMasa = precios.precioDeMasa(this.masa);
        Double precioTipo = precios.precioDeTipo(this.tipo);
        Double porcentajeTamaño = precios.porcentajeDeTamaño(this.tamaño);
        Double precioIngredientes = precios.precioDeIngredientes(this.ingredientesExtra);

        

        cadena += "MASA: " + this.masa + " - " + precioMasa + "€";
        cadena += "\n";
        cadena += "TIPO: " + this.tipo + " - " + precioTipo + "€";
        cadena += "\n";
        cadena += "INGREDIENTES EXTRA: " + this.ingredientesExtra + " - " + precioIngredientes + "€";
        cadena += "\n";
        cadena += "TAMAÑO: " + this.tamaño + " - " + porcentajeTamaño + "%";

        return cadena;
    }

    @Override
    public String toString() {
        return "Pizza " + identificador + " " + tipo + " masa " + masa;
    }

}

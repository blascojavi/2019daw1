package ventanaemergente;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.control.Label;
import javafx.scene.control.TextInputDialog;

public class FXMLDocumentController implements Initializable {

    @FXML
    private Label etiqueta;
    @FXML
    private Button boton;
    @FXML
    private Button boton1Warning;
    @FXML
    private Button botonConfirmation;
    @FXML
    private Button botonInputDialog;
    @FXML
    private Button botonInputDialogVarios;
    @FXML
    private Button botonConfirmationVArios;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void ventanaAction(ActionEvent event) {

        Alert dialogoAlerta = new Alert(AlertType.INFORMATION);
        dialogoAlerta.setTitle("Módulo de Programacion");
        dialogoAlerta.setHeaderText("Bienvenido al curso de JAVA FX");
        dialogoAlerta.setContentText("En este tema veremos las ventanas de dialogo");

        Optional<ButtonType> respuestaUsuario = dialogoAlerta.showAndWait();

        if (respuestaUsuario.isPresent() && respuestaUsuario.get() == ButtonType.OK) {
            etiqueta.setText("Has pulsado boton OK");
        } else {
            etiqueta.setText("Has cerrado la ventana");
        }

    }

    @FXML
    private void ventanaWarning(ActionEvent event) {
        Alert dialogoAlerta = new Alert(AlertType.WARNING);
        dialogoAlerta.setTitle("Módulo de Programacion");
        dialogoAlerta.setHeaderText("Ventana de aviso de algun peligro (warning)");
        dialogoAlerta.setContentText("Si te equivocas saldrá esta ventana");

        Optional<ButtonType> respuestaUsuario = dialogoAlerta.showAndWait();

        if (respuestaUsuario.isPresent() && respuestaUsuario.get() == ButtonType.OK) {
            etiqueta.setText("Has pulsado boton OK");
        } else {
            etiqueta.setText("Has cerrado la ventana");
        }
    }

    @FXML
    private void ventanaConfirmation(ActionEvent event) {
        Alert dialogoAlerta = new Alert(AlertType.CONFIRMATION);
        dialogoAlerta.setTitle("Módulo de Programacion");
        dialogoAlerta.setHeaderText("Encuenta sobre el curso de Java FX");
        dialogoAlerta.setContentText("¿Te gusta el curso de Java FX?");

        ButtonType botonSI = new ButtonType("Sí");
        ButtonType botonNO = new ButtonType("No");
        ButtonType botonAbstencion = new ButtonType("Me abstengo", ButtonData.CANCEL_CLOSE);
        dialogoAlerta.getButtonTypes().setAll(botonSI, botonNO, botonAbstencion);

        Optional<ButtonType> respuestaUsuario = dialogoAlerta.showAndWait();

        if (respuestaUsuario.isPresent()) {
            if (respuestaUsuario.get() == botonSI) {
                etiqueta.setText("Has pulsado boton SI");
            } else if (respuestaUsuario.get() == botonNO) {
                etiqueta.setText("Has pulsado boton NO");
            } else if (respuestaUsuario.get() == botonAbstencion) {
                etiqueta.setText("Has pulsado boton Abstencion");
            }
        } else {
            etiqueta.setText("Deberias pulsar un boton");
        }
    }

    @FXML
    private void ventanaInputDialog(ActionEvent event) {

        TextInputDialog dialogoInput = new TextInputDialog("aqui escribe tu nombre");
        dialogoInput.setTitle("Módulo de Programacion");
        dialogoInput.setHeaderText("Ventana para solicitar tu nombre");
        dialogoInput.setContentText("nombre");

        Optional<String> nombreUsuario = dialogoInput.showAndWait();

        if (nombreUsuario.isPresent()) {
            etiqueta.setText("Gracias " + nombreUsuario.get());
        } else {
            etiqueta.setText("No has introducido tu nombre");
        }

    }

  

    @FXML
    private void ventanaConfirmationVarios(ActionEvent event) {
        Alert dialogoAlerta = new Alert(AlertType.CONFIRMATION);
        dialogoAlerta.setTitle("Módulo de Programacion");
        dialogoAlerta.setHeaderText("Danos tu opinion del curso");
        dialogoAlerta.setContentText("Elige una opcion");

        ButtonType botonMB = new ButtonType("Muy bueno");
        ButtonType botonB = new ButtonType("Bueno");
        ButtonType botonR = new ButtonType("Regular");
        ButtonType botonMM = new ButtonType("Muy Malo");

        dialogoAlerta.getButtonTypes().setAll(botonMB, botonB, botonR, botonMM);

        Optional<ButtonType> respuestaUsuario = dialogoAlerta.showAndWait();

        if (respuestaUsuario.isPresent()) {
            etiqueta.setText("Tu eleccion ha sido : " + botonMB.getText());
        } else {
            etiqueta.setText("Necesitamos tu opinion");
        }
    }

    @FXML
    private void ventanaChoiceDialog(ActionEvent event) {
        List<String> valores = new ArrayList<>();
        valores.add("Muy bueno");
        valores.add("Bueno");
        valores.add("Regular");
        valores.add("Malo");

        ChoiceDialog<String> dialogoInput = new ChoiceDialog<>("Bueno", valores);
        dialogoInput.setTitle("Módulo de Programacion");
        dialogoInput.setHeaderText("Deseamos tu opinion");
        dialogoInput.setContentText("elige una opcion");

        Optional<String> eleccion = dialogoInput.showAndWait();

        if (eleccion.isPresent()) {
            etiqueta.setText("Tu eleccion es:  " + eleccion.get());
        } else {
            etiqueta.setText("No has introducido tu nombre");
        }

    }

}
